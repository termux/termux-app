#!/data/data/com.termux/files/usr/bin/bash
# Welcome script - sequence to be run in status pane at startup 
# Written by SealyJ
# github.com/sealedjoy
# Telegram @SealyJ
# version 0.1

clear ; figlet -f mini Welcome ; sleep 0.5; clear ; figlet -f mini to ; sleep 0.2; clear ; figlet -f slant TEL | lolcat -a --speed=150 -p 200; sleep 0.3 ; clear

