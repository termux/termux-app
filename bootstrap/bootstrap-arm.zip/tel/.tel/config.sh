#!/data/data/com.termux/files/usr/bin/sh

#TEL config is stored in this file.

STATUS_CENTER=true #center status output [true/false]
STATUS_SPACING_CHAR=" " #char to create spacing if center is enabled, try "="
STATUS_RELOAD=1m #time to sleep before reloading status
STATUS_COLOR=true #enable status color via lolcat [true/false]