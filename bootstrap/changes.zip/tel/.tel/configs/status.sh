#!/data/data/com.termux/files/usr/bin/bash

#TEL config is stored in this file.

export STATUS_ENABLED=true #status window on startup?
export STATUS_CENTER=true #center status output [true/false]
export STATUS_SPACING_CHAR=" " #char to create spacing if center is enabled, try "="
export STATUS_RELOAD=2 #time to sleep before reloading status
export STATUS_COLOR=false #enable status color via lolcat [true/false]
export STATUS_COLOR_SPREAD="100" #lolcat color spread value
export NOTIFICATIONS=true #enable notification display in status
export EDITOR=nano #used for todo -e command

