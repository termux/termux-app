#!/usr/bin/env bash
############ tel-search Preferences Configuration #########
#                   Restart to see changes                #
###########################################################
# find and edit the trusted search url list and list of search bangs inside ~/.tel/configs/search/ 
export SEARCH_LANG='en-GB' #search results format returned in iso formatted country list, search wikipedia iso formats to find your correct country/language code [must not be empty]

# See more config options in ~/.tel/configs/search/
