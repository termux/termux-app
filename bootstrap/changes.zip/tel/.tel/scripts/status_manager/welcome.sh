#!/data/data/com.termux/files/usr/bin/bash
# Welcome script - sequence to be run in status pane at startup 
# Written by SealyJ
# github.com/sealedjoy
# Telegram @SealyJ
# version 0.1
word1='Welcome'
word2='back'
word3="$NAME"

#clear
figlet -tc -f shadow "$word1" | lolcat -a --speed=170 -p 200
figlet -tc -f shadow "$word2" | lolcat -a --speed=190 -p 200
#figlet -tc -f shadow "$word3" | lolcat -a --speed=190 -p 200
#clear
figlet -tc -f shadow "$word3" | lolcat -a --speed=150 -p 200
echo ; sleep 0.1 
echo ; sleep 0.1 
echo ; sleep 0.1 
echo ; sleep 0.1 
echo ; sleep 0.1 
echo ; sleep 0.1 

clear

