#!/data/data/com.termux/files/usr/bin/bash
width=$(tput cols)
COL='\033[0;35m'
NC='\033[0m' # No Col

